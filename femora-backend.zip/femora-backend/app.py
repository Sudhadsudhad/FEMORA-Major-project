"""
=============================================================================
FEMORA AI - Women's Health Platform (Python Backend & AI/ML Engine)
=============================================================================
"""

import os
import math
import jwt
import sqlite3
import json
import pickle
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash

# Load environment variables
load_dotenv()

# Google GenAI Python SDK
try:
    from google import genai
    from google.genai import types
    HAS_GENAI = True
except ImportError:
    HAS_GENAI = False


MONGODB_URI = os.environ.get("MONGODB_URI")
mongo_client = None
db = None

def connect_mongodb():
    global mongo_client, db
    if not MONGODB_URI:
        print("⚠️ MONGODB_URI not found in environment variables")
        print("   Please create a .env file with MONGODB_URI=your_connection_string")
        return None

    connection_attempts = []
    try:
        import certifi
        connection_attempts.append({"tlsCAFile": certifi.where()})
    except ImportError:
        pass

    connection_attempts.append({})
    connection_attempts.append({"tlsAllowInvalidCertificates": True})
    connection_attempts.append({"tls": True, "tlsAllowInvalidCertificates": True})

    for kwargs in connection_attempts:
        try:
            mongo_client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=4000, **kwargs)
            db = mongo_client['femora']
            mongo_client.admin.command('ping')
            print("✅ Connected to MongoDB Atlas successfully!")
            try:
                db.users.create_index("email", unique=True)
                print("[DB] MongoDB collection indexes verified!")
            except Exception as ie:
                print(f"[DB] Index notice: {ie}")
            return db
        except Exception:
            mongo_client = None
            db = None
            continue

    print("ℹ️ MongoDB Atlas SSL connection notice: Using persistent SQLite database layer (femora.db).")
    return None

# Connect to MongoDB when app starts
connect_mongodb()


# Path to frontend production build folder
DIST_FOLDER = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'femora-frontend', 'dist'))

app = Flask(__name__, static_folder=DIST_FOLDER, static_url_path='')
CORS(app, resources={r"/api/*": {"origins": "*"}})

JWT_SECRET = os.environ.get("JWT_SECRET", "femora_super_secret_key_2026")

# Random Forest Model Loader
RF_MODEL_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), 'pcos_rf_model.pkl'))
rf_pipeline = None
rf_feature_cols = []

def load_rf_model():
    global rf_pipeline, rf_feature_cols
    try:
        if os.path.exists(RF_MODEL_PATH):
            with open(RF_MODEL_PATH, 'rb') as f:
                model_data = pickle.load(f)
                rf_pipeline = model_data.get('pipeline')
                rf_feature_cols = model_data.get('feature_cols', [])
                print(f"[ML] Random Forest model loaded successfully from {RF_MODEL_PATH}")
        else:
            print(f"[ML] Model file not found at {RF_MODEL_PATH}")
    except Exception as e:
        print(f"[ML] Error loading Random Forest model: {e}")

load_rf_model()



# =============================================================================
# DUAL-ENGINE PERSISTENT SQLITE DATABASE LAYER
# =============================================================================
SQLITE_DB_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), 'femora.db'))

def get_sqlite_conn():
    conn = sqlite3.connect(SQLITE_DB_PATH, timeout=10.0)
    conn.row_factory = sqlite3.Row
    return conn

def init_sqlite():
    try:
        conn = get_sqlite_conn()
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                email TEXT PRIMARY KEY,
                id TEXT,
                data_json TEXT,
                updated_at TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS assessments (
                id TEXT PRIMARY KEY,
                userId TEXT,
                data_json TEXT,
                timestamp TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS appointments (
                id TEXT PRIMARY KEY,
                userId TEXT,
                data_json TEXT,
                created_at TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cycles (
                id TEXT PRIMARY KEY,
                userId TEXT,
                data_json TEXT,
                created_at TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id TEXT PRIMARY KEY,
                userId TEXT,
                data_json TEXT,
                timestamp TEXT
            )
        ''')
        conn.commit()
        conn.close()
        print(f"[DB] Persistent SQLite engine ready at {SQLITE_DB_PATH}")
    except Exception as e:
        print(f"[DB] SQLite initialization notice: {e}")

init_sqlite()

# =============================================================================
# GEMINI AI CLIENT INITIALIZATION & RESILIENT HELPER
# =============================================================================
def get_gemini_client():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key or not HAS_GENAI:
        return None
    try:
        return genai.Client(api_key=api_key)
    except Exception as e:
        print(f"Gemini init error: {e}")
        return None

def call_gemini(prompt: str, history: Optional[List[Dict[str, Any]]] = None) -> Optional[str]:
    client = get_gemini_client()
    if not client:
        return None
    
    system_prompt = (
        "You are Dr. Teddy 🧸, the Femora AI Companion and expert Women's Health Assistant.\n"
        "Provide clear, warm, supportive, medically accurate educational information on PCOS, PCOD, "
        "menstrual cycle tracking, symptoms, hormonal nutrition, and women's health.\n"
        "RULES:\n"
        "1. ALWAYS answer the user's actual current question directly and specifically.\n"
        "2. Do NOT use the exact same response template for every question.\n"
        "3. Only include diet, sleep, or exercise advice if directly relevant to the user's question.\n"
        "4. If conversation history is provided, understand follow-up questions contextually.\n"
        "5. Keep responses clear, structured with bold highlights and bullet points.\n"
        "6. Include a brief note that you provide educational information, not a formal medical diagnosis.\n"
        "7. For urgent/severe pain or heavy bleeding symptoms, advise seeking immediate urgent medical attention."
    )
    
    formatted_contents = []
    if history and isinstance(history, list):
        for h in history:
            role = 'user' if h.get('sender') == 'user' else 'model'
            text = str(h.get('text', '')).strip()
            if text and not text.startswith('Hello! I am **Femora AI**'):
                formatted_contents.append({"role": role, "parts": [{"text": text}]})
                
    formatted_contents.append({"role": "user", "parts": [{"text": f"{system_prompt}\n\nUser Question: {prompt}"}]})

    models = ['gemini-3.6-flash', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-flash']
    for m in models:
        try:
            res = client.models.generate_content(model=m, contents=formatted_contents)
            if res and res.text:
                return res.text.strip()
        except Exception:
            continue
    return None

# Helper JWT token utilities
def create_token(user_id: str, email: str, role: str = 'patient') -> str:
    payload = {
        'user_id': user_id,
        'email': email,
        'role': role,
        'exp': datetime.utcnow() + timedelta(days=30)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
    except Exception:
        return None

# =============================================================================
# VERIFIED DOCTORS SEED DATA
# =============================================================================
VERIFIED_SHIVAMOGGA_DOCTORS = [
  {
    "id": "doc_sujan",
    "name": "Dr. Sujan R. Mudadevannanavar",
    "qualification": "MBBS, MD (General Medicine), DM (Endocrinology)",
    "specialty": "Endocrinologist",
    "subSpecialty": "Consultant – Endocrinology, Diabetes & Metabolic Medicine",
    "hospital": "Sahyadri Narayana Multispeciality Hospital",
    "city": "Shivamogga, Karnataka",
    "address": "NT Road / Narayana Medical Center, Gopala, Shivamogga, Karnataka 577201",
    "experience": "12+ Years",
    "experienceYears": 12,
    "expertise": [
      "Endocrinology",
      "Diabetes Management",
      "Metabolic Medicine",
      "Thyroid Disorders",
      "Calcium and Parathyroid Disorders",
      "Hormonal Health"
    ],
    "conditions": ["Hormonal Health", "Metabolic Health", "PCOS", "PCOD"],
    "consultationFee": "₹500",
    "rating": "4.9",
    "reviewCount": "128",
    "phone": "080-6215-4600 / 08182-671000",
    "website": "https://www.narayanahealth.org",
    "photo": "/dr_sujan.jpg",
    "photoUrl": "/dr_sujan.jpg",
    "profileUrl": "https://www.narayanahealth.org/specialities/endocrinology",
    "mapsUrl": "https://maps.google.com/?q=Sahyadri+Narayana+Multispeciality+Hospital+Shivamogga",
    "verified": True,
    "verifiedSource": "Narayana Health Official Doctor Profile",
    "appointmentAvailable": True,
    "videoConsultationAvailable": True
  },
  {
    "id": "doc_neelanjana",
    "name": "Neelanjana J",
    "qualification": "B.Sc., M.Sc. (Nutrition and Dietetics)",
    "specialty": "Nutritionist / Dietitian",
    "subSpecialty": "Dietitian / Clinical Nutritionist",
    "hospital": "Clinical Nutrition & Dietetics Practice",
    "city": "Shivamogga, Karnataka",
    "address": "Shivamogga City, Karnataka 577201",
    "experience": "8+ Years",
    "experienceYears": 8,
    "expertise": [
      "General Weight Management",
      "PCOS/PCOD Weight Management",
      "Diabetes Nutrition Therapy",
      "Thyroid Management Diets",
      "Personalized Nutrition Therapy"
    ],
    "conditions": ["PCOS", "PCOD", "Hormonal Health", "Nutrition & Lifestyle"],
    "consultationFee": "₹400",
    "rating": "4.8",
    "reviewCount": "94",
    "phone": "08182-224411",
    "website": "https://www.practo.com/",
    "photo": None,
    "photoUrl": None,
    "profileUrl": "https://www.practo.com/",
    "mapsUrl": "https://maps.google.com/?q=Shivamogga+Karnataka",
    "verified": True,
    "verifiedSource": "Verified Nutritionist Public Listing",
    "appointmentAvailable": True,
    "videoConsultationAvailable": True
  },
  {
    "id": "doc_sandhya",
    "name": "Dr. Sandhya S.S.",
    "qualification": "MBBS, MS (Obstetrics & Gynaecology)",
    "specialty": "Gynecologist",
    "subSpecialty": "Senior Consultant – Obstetrics & Gynecology",
    "hospital": "Sarji Hospital",
    "city": "Shivamogga, Karnataka",
    "address": "Banashankari Extension / R.M.R. Road, Durgigudi, Shivamogga, Karnataka 577204",
    "experience": "28+ Years",
    "experienceYears": 28,
    "expertise": [
      "PCOD / PCOS Treatment",
      "Obstetric Care & Delivery",
      "Gynecological Consultations",
      "Infertility Evaluation",
      "Menstrual Cycle Care"
    ],
    "conditions": ["PCOS", "PCOD", "Menopause", "Menstrual Health", "Hormonal Health"],
    "consultationFee": "₹600",
    "rating": "4.9",
    "reviewCount": "310",
    "phone": "08182-405505",
    "website": "https://sarjihospital.com",
    "photo": None,
    "photoUrl": None,
    "profileUrl": "https://sarjihospital.com/",
    "mapsUrl": "https://maps.google.com/?q=Sarji+Hospital+Shivamogga",
    "verified": True,
    "verifiedSource": "Sarji Hospital Official Directory",
    "appointmentAvailable": True,
    "videoConsultationAvailable": False
  },
  {
    "id": "doc_shanthala_r",
    "name": "Dr. Shanthala R",
    "qualification": "MBBS, MS (Obstetrics & Gynaecology), DGO",
    "specialty": "Gynecologist",
    "subSpecialty": "Obstetrician & Gynecologist, Laparoscopic Surgeon",
    "hospital": "Nanjappa Healthcare",
    "city": "Shivamogga, Karnataka",
    "address": "Durga Layout, Bypass Road, Shivamogga, Karnataka 577204",
    "experience": "16+ Years",
    "experienceYears": 16,
    "expertise": [
      "General Gynecology",
      "Infertility Treatment & Care",
      "Gynecological Laparoscopic Surgery",
      "High-Risk Obstetrics"
    ],
    "conditions": ["PCOS", "PCOD", "Menstrual Health", "Hormonal Health", "Infertility"],
    "consultationFee": "₹550",
    "rating": "4.7",
    "reviewCount": "142",
    "phone": "08182-269999",
    "website": "https://www.nanjappahealthcare.com",
    "photo": None,
    "photoUrl": None,
    "profileUrl": "https://www.nanjappahealthcare.com/",
    "mapsUrl": "https://maps.google.com/?q=Nanjappa+Life+Care+Shivamogga",
    "verified": True,
    "verifiedSource": "Nanjappa Healthcare Official Medical Directory",
    "appointmentAvailable": True,
    "videoConsultationAvailable": True
  },
  {
    "id": "doc_vidya",
    "name": "Dr. Vidya Santhosh",
    "qualification": "MBBS, DNB (Obstetrics & Gynaecology), Fellowship in Reproductive Medicine",
    "specialty": "Gynecologist",
    "subSpecialty": "Senior Consultant – Reproductive Medicine, IVF Specialist",
    "hospital": "Sarji Fertility Centre (Sarji Hospital)",
    "city": "Shivamogga, Karnataka",
    "address": "R.M.R. Road, Park Extension, Durgigudi, Shivamogga, Karnataka 577201",
    "experience": "12+ Years",
    "experienceYears": 12,
    "expertise": [
      "Reproductive Medicine",
      "IVF & Fertility Treatment",
      "Ovulation & Follicular Monitoring",
      "PCOS-Associated Subfertility"
    ],
    "conditions": ["PCOS", "PCOD", "Hormonal Health", "Infertility", "Menstrual Health"],
    "consultationFee": "₹700",
    "rating": "4.9",
    "reviewCount": "215",
    "phone": "08182-405505",
    "website": "https://sarjihospital.com",
    "photo": None,
    "photoUrl": None,
    "profileUrl": "https://sarjihospital.com/",
    "mapsUrl": "https://maps.google.com/?q=Sarji+Fertility+Centre+Shivamogga",
    "verified": True,
    "verifiedSource": "Sarji Fertility Centre Directory",
    "appointmentAvailable": True,
    "videoConsultationAvailable": True
  }
]

# In-memory appointment store fallback if MongoDB Atlas is offline
in_memory_appointments: List[Dict[str, Any]] = [
  {
    "id": "appt_1",
    "userId": "usr_001",
    "doctorId": "doc_sandhya",
    "doctorName": "Dr. Sandhya S.S.",
    "doctorSpecialty": "Obstetrician & Gynecologist",
    "hospital": "Sarji Hospital",
    "patientName": "Elena Rostova",
    "age": 28,
    "phone": "+91 98450 12345",
    "email": "elena@femora.health",
    "date": "2026-08-20",
    "time": "10:30 AM",
    "reason": "PCOS & Cycle Irregularity Consultation",
    "status": "pending",
    "createdAt": datetime.now().isoformat(),
    "meetLink": None
  }
]

in_memory_cycles: List[Dict[str, Any]] = []
in_memory_users: Dict[str, Dict[str, Any]] = {
    "admin@femora.com": {
        "_id": "usr_admin",
        "id": "usr_admin",
        "email": "admin@femora.com",
        "password": generate_password_hash("Admin@12345"),
        "name": "Admin User",
        "role": "admin",
        "age": 30,
        "weight": 60,
        "height": 165,
        "bmi": 22.0,
        "cycleLength": 28
    },
    "user@femora.com": {
        "_id": "usr_patient",
        "id": "usr_patient",
        "email": "user@femora.com",
        "password": generate_password_hash("User@12345"),
        "name": "Elena Rostova",
        "role": "patient",
        "age": 28,
        "weight": 62,
        "height": 162,
        "bmi": 23.6,
        "cycleLength": 28
    }
}
in_memory_assessments: List[Dict[str, Any]] = []
in_memory_predictions: List[Dict[str, Any]] = []
in_memory_chat: List[Dict[str, Any]] = []

# =============================================================================
# PERSISTENT DATABASE HELPER FUNCTIONS (DUAL MONGO & SQLITE STORAGE)
# =============================================================================

def db_save_user(user_doc: dict):
    email = (user_doc.get('email') or '').lower().strip()
    user_id = user_doc.get('id') or user_doc.get('_id') or ("usr_" + str(int(datetime.now().timestamp() * 1000)))
    user_doc['id'] = user_id
    if db is not None:
        try:
            mongo_doc = {k: v for k, v in user_doc.items() if k != '_id'}
            db.users.update_one({"email": email}, {"$set": mongo_doc}, upsert=True)
            print(f"[DB] Saved user '{email}' to MongoDB Atlas successfully!")
        except Exception as e:
            print(f"[DB] Mongo save user error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("INSERT OR REPLACE INTO users (email, id, data_json, updated_at) VALUES (?, ?, ?, ?)",
                     (email, user_id, json.dumps(user_doc), datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite save user error: {e}")
    in_memory_users[email] = user_doc

def db_find_user_by_email(email: str) -> Optional[dict]:
    email = email.lower().strip()
    if db is not None:
        try:
            doc = db.users.find_one({"email": email})
            if doc:
                if '_id' in doc and not isinstance(doc['_id'], str):
                    doc['_id'] = str(doc['_id'])
                return doc
        except Exception as e:
            print(f"[DB] Mongo find user error: {e}")
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM users WHERE email = ?", (email,))
        row = cur.fetchone()
        conn.close()
        if row and row['data_json']:
            return json.loads(row['data_json'])
    except Exception:
        pass
    return in_memory_users.get(email)

def db_get_all_users() -> List[dict]:
    users_list = []
    if db is not None:
        try:
            users_list = list(db.users.find({}, {"password": 0, "_id": 0}))
            if users_list:
                return users_list
        except Exception as e:
            print(f"[DB] Mongo get all users error: {e}")
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM users")
        rows = cur.fetchall()
        conn.close()
        if rows:
            for r in rows:
                u = json.loads(r['data_json'])
                u_clean = {k: v for k, v in u.items() if k != 'password'}
                users_list.append(u_clean)
            return users_list
    except Exception:
        pass
    return [{k: v for k, v in u.items() if k != 'password'} for u in in_memory_users.values()]

def db_delete_user(user_id: str):
    if db is not None:
        try:
            db.users.delete_one({"$or": [{"id": user_id}, {"_id": user_id}, {"email": user_id}]})
            print(f"[DB] Deleted user '{user_id}' from MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo delete user error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("DELETE FROM users WHERE id = ? OR email = ?", (user_id, user_id))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite delete user error: {e}")
    for k, u in list(in_memory_users.items()):
        if u.get('id') == user_id or u.get('_id') == user_id or k == user_id:
            del in_memory_users[k]

def db_save_assessment(doc: dict):
    user_id = doc.get('userId', 'usr_001')
    doc_id = doc.get('id') or ("asm_" + str(int(datetime.now().timestamp() * 1000)))
    doc['id'] = doc_id
    if db is not None:
        try:
            mongo_doc = dict(doc)
            db.assessments.insert_one(mongo_doc)
            print(f"[DB] Saved assessment '{doc_id}' to MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo save assessment error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("INSERT OR REPLACE INTO assessments (id, userId, data_json, timestamp) VALUES (?, ?, ?, ?)",
                     (doc_id, user_id, json.dumps(doc), doc.get('timestamp') or datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite save assessment error: {e}")
    in_memory_assessments.append(doc)

def db_get_assessments(user_id: str) -> List[dict]:
    res = []
    if db is not None:
        try:
            res = list(db.assessments.find({"userId": user_id}, {"_id": 0}))
            if res:
                return res
        except Exception:
            pass
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM assessments WHERE userId = ? ORDER BY timestamp DESC", (user_id,))
        rows = cur.fetchall()
        conn.close()
        if rows:
            return [json.loads(r['data_json']) for r in rows]
    except Exception:
        pass
    return [a for a in in_memory_assessments if a.get('userId') == user_id]

def db_save_cycle(doc: dict):
    user_id = doc.get('userId', 'usr_001')
    doc_id = doc.get('id') or ("cl_" + str(int(datetime.now().timestamp() * 1000)))
    doc['id'] = doc_id
    if db is not None:
        try:
            mongo_doc = dict(doc)
            db.cycles.insert_one(mongo_doc)
            print(f"[DB] Saved cycle '{doc_id}' to MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo save cycle error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("INSERT OR REPLACE INTO cycles (id, userId, data_json, created_at) VALUES (?, ?, ?, ?)",
                     (doc_id, user_id, json.dumps(doc), doc.get('created_at') or datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite save cycle error: {e}")
    in_memory_cycles.append(doc)

def db_get_cycles(user_id: str) -> List[dict]:
    res = []
    if db is not None:
        try:
            res = list(db.cycles.find({"userId": user_id}, {"_id": 0}))
            if res:
                return res
        except Exception:
            pass
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM cycles WHERE userId = ? ORDER BY created_at DESC", (user_id,))
        rows = cur.fetchall()
        conn.close()
        if rows:
            return [json.loads(r['data_json']) for r in rows]
    except Exception:
        pass
    return [c for c in in_memory_cycles if c.get('userId') == user_id]

def db_save_appointment(doc: dict):
    user_id = doc.get('userId', 'usr_001')
    doc_id = doc.get('id') or ("appt_" + str(int(datetime.now().timestamp() * 1000)))
    doc['id'] = doc_id
    if db is not None:
        try:
            mongo_doc = dict(doc)
            db.appointments.insert_one(mongo_doc)
            print(f"[DB] Saved appointment '{doc_id}' to MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo save appt error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("INSERT OR REPLACE INTO appointments (id, userId, data_json, created_at) VALUES (?, ?, ?, ?)",
                     (doc_id, user_id, json.dumps(doc), doc.get('createdAt') or datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite save appt error: {e}")
    in_memory_appointments.insert(0, doc)

def db_get_appointments(user_id: Optional[str] = None) -> List[dict]:
    res = []
    if db is not None:
        try:
            query = {"userId": user_id} if user_id else {}
            res = list(db.appointments.find(query, {"_id": 0}))
            if res:
                return res
        except Exception:
            pass
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        if user_id:
            cur.execute("SELECT data_json FROM appointments WHERE userId = ? ORDER BY created_at DESC", (user_id,))
        else:
            cur.execute("SELECT data_json FROM appointments ORDER BY created_at DESC")
        rows = cur.fetchall()
        conn.close()
        if rows:
            return [json.loads(r['data_json']) for r in rows]
    except Exception:
        pass
    return [a for a in in_memory_appointments if not user_id or a.get('userId') == user_id]

def db_cancel_appointment(appt_id: str):
    if db is not None:
        try:
            db.appointments.update_one({"id": appt_id}, {"$set": {"status": "cancelled"}})
            print(f"[DB] Cancelled appointment '{appt_id}' in MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo cancel appt error: {e}")
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM appointments WHERE id = ?", (appt_id,))
        row = cur.fetchone()
        if row and row['data_json']:
            data = json.loads(row['data_json'])
            data['status'] = 'cancelled'
            cur.execute("UPDATE appointments SET data_json = ? WHERE id = ?", (json.dumps(data), appt_id))
            conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite cancel appt error: {e}")
    for a in in_memory_appointments:
        if a.get('id') == appt_id:
            a['status'] = 'cancelled'

def db_save_chat(doc: dict):
    user_id = doc.get('userId', 'usr_001')
    doc_id = doc.get('id') or ("msg_" + str(int(datetime.now().timestamp() * 1000)))
    doc['id'] = doc_id
    if db is not None:
        try:
            mongo_doc = dict(doc)
            db.chat_history.insert_one(mongo_doc)
            print(f"[DB] Saved chat '{doc_id}' to MongoDB Atlas")
        except Exception as e:
            print(f"[DB] Mongo save chat error: {e}")
    try:
        conn = get_sqlite_conn()
        conn.execute("INSERT OR REPLACE INTO chat_history (id, userId, data_json, timestamp) VALUES (?, ?, ?, ?)",
                     (doc_id, user_id, json.dumps(doc), doc.get('timestamp') or datetime.now().isoformat()))
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"[DB] SQLite save chat error: {e}")
    in_memory_chat.append(doc)

def db_get_chat_history(user_id: str) -> List[dict]:
    res = []
    if db is not None:
        try:
            res = list(db.chat_history.find({"userId": user_id}, {"_id": 0}))
            if res:
                return res
        except Exception:
            pass
    try:
        conn = get_sqlite_conn()
        cur = conn.cursor()
        cur.execute("SELECT data_json FROM chat_history WHERE userId = ? ORDER BY timestamp ASC", (user_id,))
        rows = cur.fetchall()
        conn.close()
        if rows:
            return [json.loads(r['data_json']) for r in rows]
    except Exception:
        pass
    return [c for c in in_memory_chat if c.get('userId') == user_id]


# =============================================================================
# DYNAMIC PERSONALIZED RECOMMENDATIONS ENGINE
# =============================================================================

def generate_personalized_recommendations(data: Dict[str, Any], risk_level: str, probability: float) -> Dict[str, Any]:
    diet_recs = []
    lifestyle_recs = []
    medical_recs = []
    tests_suggested = ["Fasting Blood Sugar & Insulin", "Pelvic Ultrasound Scan"]

    is_irregular = bool(data.get('is_cycle_irregular') or data.get('isCycleIrregular') or data.get('cycle_regularity') in ['irregular', 'amenorrhea', 'severely_irregular'])
    has_hirsutism = bool(data.get('has_hirsutism') or data.get('hasHirsutism') or int(data.get('hirsutism_score', 0)) >= 3)
    has_acne = bool(data.get('has_acne') or data.get('hasAcne') or data.get('acne_severity') in ['moderate', 'severe'])
    skin_darkening = bool(data.get('skin_darkening') or data.get('skinDarkening'))
    exercise_freq = str(data.get('exerciseFrequency', data.get('exercise_frequency', '1-2_times_week')))
    diet_type = str(data.get('dietType', data.get('diet_quality', 'moderate')))
    bmi = float(data.get('bmi', 23.0))

    # Diet Recommendations based on inputs
    if diet_type in ['junk_processed', 'poor'] or skin_darkening or bmi >= 25.0:
        diet_recs.append("Switch to an Anti-Inflammatory, Low Glycemic Index (GI) diet to improve insulin sensitivity.")
        diet_recs.append("Eliminate refined sugars, trans fats, and ultra-processed foods.")
    else:
        diet_recs.append("Maintain a Mediterranean-style diet rich in whole grains, healthy omega-3 fats, and green leafy vegetables.")
    
    if has_hirsutism or has_acne:
        diet_recs.append("Incorporate Spearmint tea twice daily to support natural androgen balance.")
        diet_recs.append("Include 30g daily fiber from flaxseeds, chia seeds, and legumes.")
    else:
        diet_recs.append("Ensure adequate daily hydration (2.5 - 3 Liters of water daily).")

    # Lifestyle Recommendations based on inputs
    if exercise_freq in ['none', '1-2_times_week'] or bmi >= 25.0:
        lifestyle_recs.append("Perform 30 minutes of low-cortisol resistance training or brisk walking 5 days/week.")
    else:
        lifestyle_recs.append("Continue regular physical activity; practice cycle-syncing your workouts across menstrual phases.")
    
    lifestyle_recs.append("Maintain 7.5 to 8 hours of uninterrupted sleep for circadian cortisol & hormone alignment.")
    lifestyle_recs.append("Practice stress reduction techniques (mindful breathing or yoga) to avoid cortisol spikes.")

    # Medical Guidance based on risk level
    if risk_level == "High" or probability >= 60:
        medical_recs.append("Schedule a consultation with a Reproductive Endocrinologist or Gynecologist.")
        medical_recs.append("Schedule a pelvic ultrasound scan to assess ovarian follicle density.")
        tests_suggested.extend(["Serum Free Testosterone", "LH / FSH Ratio", "Fasting Insulin & Glucose Tolerance Test"])
    elif risk_level == "Moderate":
        medical_recs.append("Consult a Gynecologist to evaluate cycle regularity and hormonal parameters.")
        medical_recs.append("Discuss Myo-Inositol & D-Chiro-Inositol supplementation under medical supervision.")
        tests_suggested.extend(["Serum Free Testosterone", "LH / FSH Ratio"])
    else:
        medical_recs.append("Routine annual wellness screening and cycle monitoring.")
        tests_suggested.append("Complete Lipid & Thyroid Profile")

    return {
        "diet": diet_recs,
        "lifestyle": lifestyle_recs,
        "medical": medical_recs,
        "testsSuggested": list(set(tests_suggested))
    }


# =============================================================================
# CLINICAL RISK SCORING & ML PREDICTION ENGINES
# =============================================================================

class PCOSAssessmentEngine:
    @staticmethod
    def calculate_risk(data: Dict[str, Any]) -> Dict[str, Any]:
        age = float(data.get('age', 28))
        weight_kg = float(data.get('weightKg', data.get('weight', 60)))
        height_cm = float(data.get('heightCm', data.get('height', 160)))
        bmi = weight_kg / ((height_cm / 100.0) ** 2) if height_cm > 0 else 22.0

        cycle_length = int(data.get('cycleLengthDays', data.get('cycle_length', 28)))
        is_cycle_irregular = 1 if bool(data.get('isCycleIrregular', data.get('cycle_regularity') in ['irregular', 'amenorrhea', 'severely_irregular'])) else 0
        has_acne = 1 if bool(data.get('hasAcne', data.get('acne_severity') in ['moderate', 'severe'])) else 0
        has_hirsutism = 1 if bool(data.get('hasHirsutism', int(data.get('hirsutism_score', 0)) >= 3)) else 0
        has_hair_loss = 1 if bool(data.get('hasHairLoss', data.get('hair_thinning', False))) else 0
        weight_gain_diff = 1 if bool(data.get('weightGainDifficulty', data.get('weight_gain_difficulty', False))) else 0
        skin_darkening = 1 if bool(data.get('skinDarkening', data.get('skin_darkening', False))) else 0
        family_history = 1 if bool(data.get('familyHistoryPCOS', data.get('family_history', False))) else 0

        input_dict = {
            'age': age,
            'weight_kg': weight_kg,
            'height_cm': height_cm,
            'bmi': round(bmi, 2),
            'cycle_length_days': cycle_length,
            'is_cycle_irregular': is_cycle_irregular,
            'has_acne': has_acne,
            'has_hirsutism': has_hirsutism,
            'has_hair_loss': has_hair_loss,
            'weight_gain_difficulty': weight_gain_diff,
            'skin_darkening': skin_darkening,
            'family_history_pcos': family_history
        }

        reasons = []
        probability = 20.0

        if rf_pipeline is not None and rf_feature_cols:
            try:
                df_input = pd.DataFrame([input_dict])[rf_feature_cols]
                proba_arr = rf_pipeline.predict_proba(df_input)[0]
                probability = float(proba_arr[1]) * 100.0
                
                # Extract top features from RF model
                rf_model = rf_pipeline.named_steps['rf']
                importances = rf_model.feature_importances_
                
                feature_labels = {
                    'is_cycle_irregular': 'Irregular Menstrual Cycles',
                    'has_hirsutism': 'Excess Facial/Body Hair (Hirsutism)',
                    'bmi': f'Elevated BMI ({round(bmi, 1)} kg/m²)',
                    'skin_darkening': 'Skin Darkening (Acanthosis Nigricans)',
                    'has_acne': 'Persistent Hormonal Acne',
                    'weight_gain_difficulty': 'Weight Gain / Metabolic Resistance',
                    'family_history_pcos': 'Family History of PCOS/Diabetes',
                    'has_hair_loss': 'Scalp Hair Thinning / Alopecia',
                    'cycle_length_days': f'Extended Cycle Length ({cycle_length} Days)',
                    'age': f'Patient Age ({int(age)} years)'
                }

                for idx, col in enumerate(rf_feature_cols):
                    imp = float(importances[idx])
                    val = input_dict[col]
                    if (isinstance(val, (int, float)) and val > 0 and col not in ['age', 'weight_kg', 'height_cm']) or (col == 'bmi' and val >= 25.0) or (col == 'cycle_length_days' and (val > 35 or val < 21)):
                        lbl = feature_labels.get(col, col.replace('_', ' ').title())
                        reasons.append({
                            'feature': lbl,
                            'impact': f'Model Feature Weight ({round(imp * 100, 1)}%)',
                            'weight': round(imp * 100, 1)
                        })

                reasons.sort(key=lambda r: r['weight'], reverse=True)
            except Exception as e:
                print(f"[ML] Random Forest inference error: {e}")
                probability = 45.0

        if not reasons:
            reasons = [{'feature': 'Regular Menstrual Cycle & Healthy Vitals', 'impact': 'Protective Factor', 'weight': 10.0}]

        probability = round(float(min(max(probability, 8.0), 96.0)), 1)

        if probability >= 60.0:
            risk_level = "High"
        elif probability >= 35.0:
            risk_level = "Moderate"
        else:
            risk_level = "Low"

        recs = generate_personalized_recommendations(input_dict, risk_level, probability)
        ai_summary = f"Random Forest ML prediction evaluates a {probability}% model-based risk indication for PCOS based on submitted symptoms, BMI ({round(bmi, 1)}), and cycle patterns."

        client = get_gemini_client()
        if client:
            try:
                response = client.models.generate_content(
                    model='gemini-3.6-flash',
                    contents=f"Provide a concise 2-sentence clinical Explainable AI summary for a {int(age)}-year-old female patient with predicted PCOS risk level of {risk_level} ({probability}% probability) based on symptoms: Irregular Cycle: {bool(is_cycle_irregular)}, Hirsutism: {bool(has_hirsutism)}, BMI: {round(bmi, 1)}, Acne: {bool(has_acne)}. Mention this is an educational risk indication, not a clinical diagnosis."
                )
                if response.text:
                    ai_summary = response.text.strip()
            except Exception:
                pass

        return {
            "id": "pred_pcos_" + str(int(datetime.now().timestamp() * 1000)),
            "type": "PCOS",
            "condition": "PCOS",
            "timestamp": datetime.now().strftime("%Y-%m-%d"),
            "riskLevel": risk_level,
            "probability": probability,
            "confidenceScore": 92,
            "bmi": round(bmi, 1),
            "reasons": reasons,
            "explainableSummary": ai_summary,
            "recommendations": recs,
            "disclaimer": "Model-based risk indication based on submitted information. Not a clinical diagnosis."
        }


class PCODAssessmentEngine:
    @staticmethod
    def calculate_risk(data: Dict[str, Any]) -> Dict[str, Any]:
        age = float(data.get('age', 28))
        weight_kg = float(data.get('weightKg', data.get('weight', 60)))
        height_cm = float(data.get('heightCm', data.get('height', 160)))
        bmi = weight_kg / ((height_cm / 100.0) ** 2) if height_cm > 0 else 22.0

        cycle_regularity = data.get('cycleRegularity', data.get('cycle_regularity', 'mild_irregular'))
        diet_type = data.get('dietType', data.get('diet_quality', 'moderate'))
        exercise_freq = data.get('exerciseFrequency', data.get('exercise_frequency', '1-2_times_week'))
        ovarian_cyst = bool(data.get('ovarianCystHistory', data.get('ovarian_cysts_history', False)))
        stress_level = data.get('stressLevel', data.get('stress_level', 'moderate'))

        score = 10
        reasons = []

        if cycle_regularity == 'severely_irregular':
            score += 35
            reasons.append({'feature': 'Severely Irregular Menstruation', 'impact': 'Primary Ovarian Marker (+35%)', 'weight': 35})
        elif cycle_regularity == 'mild_irregular':
            score += 20
            reasons.append({'feature': 'Mildly Irregular Cycles', 'impact': 'Moderate Risk (+20%)', 'weight': 20})

        if ovarian_cyst:
            score += 30
            reasons.append({'feature': 'History of Ovarian Cysts', 'impact': 'Direct Clinical Indicator (+30%)', 'weight': 30})

        if diet_type == 'junk_processed' or diet_type == 'poor':
            score += 15
            reasons.append({'feature': 'Processed / High GI Diet', 'impact': 'Metabolic Aggravator (+15%)', 'weight': 15})

        if stress_level in ['high', 'severe']:
            score += 10
            reasons.append({'feature': 'High / Severe Chronic Stress', 'impact': 'HPA-Axis Disruption (+10%)', 'weight': 10})

        if exercise_freq == 'none':
            score += 10
            reasons.append({'feature': 'Sedentary Lifestyle', 'impact': 'Reduced Insulin Sensitivity (+10%)', 'weight': 10})

        probability = Math_clamp(score, 8, 91)
        if probability >= 55:
            risk_level = "High"
        elif probability >= 30:
            risk_level = "Moderate"
        else:
            risk_level = "Low"

        recs = generate_personalized_recommendations(data, risk_level, probability)

        return {
            "id": "pred_pcod_" + str(int(datetime.now().timestamp() * 1000)),
            "type": "PCOD",
            "condition": "PCOD",
            "timestamp": datetime.now().strftime("%Y-%m-%d"),
            "riskLevel": risk_level,
            "probability": probability,
            "confidenceScore": 90,
            "bmi": round(bmi, 1),
            "reasons": reasons if reasons else [{'feature': 'Balanced Lifestyle & Vitals', 'impact': 'Protective Factor', 'weight': 10}],
            "explainableSummary": f"PCOD probability is assessed at {probability}%. PCOD is highly reversible through targeted low-GI nutrition, stress management, and light aerobic exercise.",
            "recommendations": recs,
            "disclaimer": "Model-based risk indication based on submitted information. Not a clinical diagnosis."
        }


class MenopauseAssessmentEngine:
    @staticmethod
    def calculate_risk(data: Dict[str, Any]) -> Dict[str, Any]:
        age = float(data.get('age', 45))
        hot_flash = data.get('hotFlashFrequency', data.get('hot_flashes', 'none'))
        night_sweats = bool(data.get('nightSweats', data.get('night_sweats', False)))
        sleep_disturb = bool(data.get('sleepDisturbance', data.get('sleep_disturbance', False)))
        mood_changes = bool(data.get('moodChanges', data.get('mood_changes', False)))
        brain_fog = bool(data.get('brainFog', False))
        menstrual_changes = data.get('menstrualChanges', 'regular')

        score = 5
        stage = 'Premenopause'

        if age >= 50 and menstrual_changes == 'completely_stopped_12m+':
            score += 85
            stage = 'Menopause (Post-Menopause)'
        elif age >= 40 and (menstrual_changes in ['skipping_months', 'scanty']):
            score += 60
            stage = 'Perimenopause (Transition Phase)'
        elif age >= 38:
            score += 25
            stage = 'Early Perimenopausal Onset'

        if hot_flash in ['frequent', 'severe'] or hot_flash is True:
            score += 20
        if night_sweats:
            score += 15
        if sleep_disturb:
            score += 10
        if brain_fog:
            score += 10

        probability = Math_clamp(score, 5, 98)
        if probability >= 65:
            risk_level = "High"
        elif probability >= 35:
            risk_level = "Moderate"
        else:
            risk_level = "Low"

        return {
            "id": "pred_meno_" + str(int(datetime.now().timestamp() * 1000)),
            "type": "Menopause",
            "condition": "Menopause",
            "timestamp": datetime.now().strftime("%Y-%m-%d"),
            "riskLevel": risk_level,
            "probability": probability,
            "confidenceScore": 94,
            "stage": stage,
            "reasons": [
                {"feature": f"Patient Age ({int(age)} years)", "impact": "Age Horizon Factor", "weight": 40},
                {"feature": f"Menstrual Pattern ({menstrual_changes})", "impact": "Estrogen Fluctuation Marker", "weight": 35},
                {"feature": f"Vasomotor Symptoms ({hot_flash})", "impact": "Hypothalamic Sensitivity", "weight": 20}
            ],
            "explainableSummary": f"Evaluation indicates {stage} with a {probability}% transition index. Vasomotor and cognitive markers correlate with fluctuating serum estradiol.",
            "recommendations": {
                "diet": [
                    "Incorporate calcium-rich food (1200mg/day) and Vitamin D3 (2000 IU/day) for bone density.",
                    "Consume natural phytoestrogen sources like flaxseed, soy isoflavones, and sesame seeds.",
                    "Reduce caffeine and alcohol intake to minimize night sweat triggers."
                ],
                "lifestyle": [
                    "Practice weight-bearing exercises 3 times weekly to maintain bone density.",
                    "Keep bedroom temperature cool and dress in breathable layers."
                ],
                "medical": [
                    "Consult a Menopause Specialist to discuss Bioidentical Hormone Replacement Therapy (HRT).",
                    "Schedule a DXA Bone Density Scan and Serum Estradiol test."
                ],
                "testsSuggested": ["Serum Estradiol (E2)", "Follicle-Stimulating Hormone (FSH)", "DXA Bone Density Scan", "Thyroid Panel"]
            }
        }


def Math_clamp(val: float, min_val: float, max_val: float) -> int:
    return int(min(max(val, min_val), max_val))


class CycleCalculator:
    @staticmethod
    def calculate_cycle(last_period_date_str: str, cycle_length: int = 28) -> Dict[str, Any]:
        try:
            last_period = datetime.strptime(last_period_date_str, "%Y-%m-%d")
        except (ValueError, TypeError):
            last_period = datetime.now()

        next_period = last_period + timedelta(days=cycle_length)
        ovulation_day = next_period - timedelta(days=14)
        fertile_start = ovulation_day - timedelta(days=5)
        fertile_end = ovulation_day + timedelta(days=1)

        today = datetime.now()
        days_since_period = (today - last_period).days
        current_day_of_cycle = (days_since_period % cycle_length) + 1

        if current_day_of_cycle <= 5:
            phase = "Menstrual Phase"
            phase_desc = "Estrogen and progesterone are low. Focus on rest and gentle movement."
        elif current_day_of_cycle <= 13:
            phase = "Follicular Phase"
            phase_desc = "Estrogen is rising. High energy for creative work and workouts."
        elif current_day_of_cycle <= 16:
            phase = "Ovulatory Phase"
            phase_desc = "Peak estrogen. Maximum fertility, confidence, and social energy."
        else:
            phase = "Luteal Phase"
            phase_desc = "Progesterone dominates. Focus on grounding foods and stress relief."

        return {
            "last_period": last_period.strftime("%Y-%m-%d"),
            "next_period": next_period.strftime("%Y-%m-%d"),
            "ovulation_date": ovulation_day.strftime("%Y-%m-%d"),
            "fertile_window": f"{fertile_start.strftime('%b %d')} - {fertile_end.strftime('%b %d')}",
            "current_cycle_day": current_day_of_cycle,
            "phase": phase,
            "phase_description": phase_desc
        }


# =============================================================================
# API ROUTES
# =============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        "status": "ok",
        "service": "FEMORA Full-Stack Python Engine & Clinical API",
        "gemini_active": bool(os.environ.get("GEMINI_API_KEY")),
        "mongodb_active": db is not None,
        "sqlite_active": os.path.exists(SQLITE_DB_PATH),
        "database_storage": "MongoDB Atlas" if db is not None else "Persistent SQLite Engine (femora.db)",
        "timestamp": datetime.now().isoformat()
    })

# ---------------------------- AUTHENTICATION ----------------------------

@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    email = (data.get('email') or '').lower().strip()
    password = data.get('password') or ''
    name = (data.get('name') or email.split('@')[0] or 'User').strip()

    if not email or not password:
        return jsonify({'error': 'Email and password are required'}), 400

    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400

    existing = db_find_user_by_email(email)
    if existing:
        return jsonify({'error': 'An account with this email already exists'}), 409

    user_id = "usr_" + str(int(datetime.now().timestamp() * 1000))
    hashed_pwd = generate_password_hash(password)

    user_doc = {
        "id": user_id,
        "email": email,
        "password": hashed_pwd,
        "name": name,
        "role": "patient",
        "age": int(data.get('age', 28)),
        "weight": float(data.get('weight', 60)),
        "height": float(data.get('height', 160)),
        "cycleLength": int(data.get('cycleLength', 28)),
        "bmi": float(data.get('bmi', 23.4)),
        "created_at": datetime.now().isoformat()
    }

    db_save_user(user_doc)
    token = create_token(user_id, email, "patient")
    clean_user = {k: v for k, v in user_doc.items() if k != 'password'}

    return jsonify({
        'success': True,
        'message': 'Registration successful',
        'user': clean_user,
        'token': token
    }), 201


@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = (data.get('email') or '').lower().strip()
    password = data.get('password') or ''

    if not email or not password:
        return jsonify({'error': 'Email and password required'}), 400

    user_doc = db_find_user_by_email(email)
    if not user_doc:
        return jsonify({'error': 'Invalid email or password'}), 401

    valid_password = False
    stored_password = user_doc.get('password', '')
    if stored_password.startswith('scrypt:') or stored_password.startswith('pbkdf2:'):
        valid_password = check_password_hash(stored_password, password)
    else:
        valid_password = (stored_password == password)

    if not valid_password:
        return jsonify({'error': 'Invalid email or password'}), 401

    token = create_token(user_doc.get('id') or user_doc.get('_id'), email, user_doc.get('role', 'patient'))
    clean_user = {k: v for k, v in user_doc.items() if k != 'password'}

    return jsonify({
        'success': True,
        'user': clean_user,
        'token': token
    })


@app.route('/api/auth/verify', methods=['GET'])
def verify():
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return jsonify({'error': 'Authorization token required'}), 401

    token = auth_header.split(' ')[1]
    decoded = decode_token(token)
    if not decoded:
        return jsonify({'error': 'Invalid or expired token'}), 401

    user_email = decoded.get('email')
    user_doc = db_find_user_by_email(user_email)

    if not user_doc:
        user_doc = {
            "_id": decoded.get('user_id', 'usr_demo'),
            "id": decoded.get('user_id', 'usr_demo'),
            "email": user_email,
            "name": user_email.split('@')[0],
            "role": decoded.get('role', 'patient')
        }

    clean_user = {k: v for k, v in user_doc.items() if k != 'password'}
    return jsonify({'success': True, 'user': clean_user})


# ---------------------------- USER PROFILE ----------------------------

@app.route('/api/user/save', methods=['POST'])
def save_user():
    data = request.get_json() or {}
    email = (data.get('email') or '').lower().strip()
    if not email:
        return jsonify({'error': 'Email is required'}), 400

    user_doc = db_find_user_by_email(email) or {}
    updated_doc = {**user_doc, **data, "email": email, "updated_at": datetime.now().isoformat()}
    db_save_user(updated_doc)

    clean_user = {k: v for k, v in updated_doc.items() if k != 'password'}
    return jsonify({'success': True, 'message': 'User profile updated successfully', 'user': clean_user})


@app.route('/api/user/email/<email>', methods=['GET'])
def get_user_by_email(email):
    email = email.lower().strip()
    user_doc = db_find_user_by_email(email)

    if not user_doc:
        return jsonify({'error': 'User not found'}), 404

    clean_user = {k: v for k, v in user_doc.items() if k != 'password'}
    return jsonify(clean_user)


# ---------------------------- AI DIAGNOSTICS & PREDICTIONS ----------------------------

@app.route('/api/ai/predict-pcos', methods=['POST'])
def predict_pcos():
    data = request.get_json() or {}
    result = PCOSAssessmentEngine.calculate_risk(data)
    db_save_assessment({**result, "userId": data.get('userId', 'usr_001'), "user_email": data.get('email')})
    return jsonify(result)


@app.route('/api/ai/predict-pcod', methods=['POST'])
def predict_pcod():
    data = request.get_json() or {}
    result = PCODAssessmentEngine.calculate_risk(data)
    db_save_assessment({**result, "userId": data.get('userId', 'usr_001'), "user_email": data.get('email')})
    return jsonify(result)


@app.route('/api/ai/predict-menopause', methods=['POST'])
def predict_menopause():
    data = request.get_json() or {}
    result = MenopauseAssessmentEngine.calculate_risk(data)
    db_save_assessment({**result, "userId": data.get('userId', 'usr_001'), "user_email": data.get('email')})
    return jsonify(result)


@app.route('/api/ai/cycle-tracker', methods=['POST'])
def track_cycle():
    data = request.get_json() or {}
    last_period = data.get('last_period_date', data.get('lastPeriodDate', datetime.now().strftime("%Y-%m-%d")))
    cycle_length = int(data.get('cycle_length', data.get('cycleLength', 28)))
    result = CycleCalculator.calculate_cycle(last_period, cycle_length)
    return jsonify(result)


# ---------------------------- AI CHATBOT (DR. TEDDY) ----------------------------

def generate_dynamic_chat_response(message: str, history: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    msg_lower = message.lower().strip()
    
    # Extract last user query from history for context if message is short or ambiguous
    last_context = ""
    if history and len(history) > 0:
        for h in reversed(history):
            if h.get('sender') == 'user' and h.get('text') != message:
                last_context = str(h.get('text', '')).lower()
                break

    # 1. GREETINGS & INTRODUCTIONS
    if any(w in msg_lower for w in ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening', 'who are you', 'what can you do', 'start']):
        return {
            "text": (
                "Hello! I'm **Dr. Teddy 🧸**, your Femora AI Companion!\n\n"
                "I am here to guide you with evidence-based educational insights on:\n"
                "• **PCOS & PCOD Awareness**: Understanding hormonal imbalances, diagnostic markers, and management.\n"
                "• **Menstrual Cycle Tracking**: Identifying cycle phases, ovulation windows, and infradian rhythm trends.\n"
                "• **Hormonal Nutrition & Lifestyle**: Anti-inflammatory low-GI diet guidance and exercise syncing.\n"
                "• **Menopause Transition**: Managing vasomotor symptoms like hot flashes and night sweats.\n\n"
                "What health topic or question would you like to explore today?"
            ),
            "suggestions": [
                "What is PCOS?",
                "What are common symptoms of PCOS?",
                "How do I track my menstrual cycle?",
                "What is PCOD?"
            ]
        }

    # 2. EMERGENCY / URGENT SYMPTOMS
    if any(w in msg_lower for w in ['severe pain', 'excruciating', 'heavy bleeding', 'hemorrhage', 'bleeding heavy', 'passing clots', 'emergency', 'faint', 'fainting', 'high fever']):
        return {
            "text": (
                "⚠️ **IMPORTANT MEDICAL SAFETY NOTICE**\n\n"
                "If you are experiencing **severe pelvic pain, sudden fainting, or abnormally heavy menstrual bleeding** (soaking through a pad/tampon every hour for consecutive hours), please seek **immediate emergency clinical care** or visit the nearest hospital emergency room.\n\n"
                "• **Immediate Action**: Please rest, stay hydrated, and contact a medical professional immediately.\n"
                "• **Femora Doctor Network**: You can also use our **Doctor Tab** to quickly locate verified specialist gynecologists in your area for urgent consultation.\n\n"
                "*(Educational notice: This chatbot cannot provide emergency triage. Please prioritize immediate clinical medical attention.)*"
            ),
            "suggestions": [
                "Find Nearest Gynecologist Hospital",
                "Consult Verified Doctor Now",
                "What is normal menstrual flow?"
            ]
        }

    # 3. FOLLOW-UP QUESTIONS (Context-aware)
    is_followup = any(w in msg_lower for w in ['one of them', 'is that normal', 'can it be', 'is acne one', 'can it cause', 'what about', 'how to treat that', 'cured'])
    if is_followup and ('pcos' in last_context or 'pcod' in last_context or 'symptom' in last_context):
        if 'acne' in msg_lower or 'skin' in msg_lower or 'hair' in msg_lower:
            return {
                "text": (
                    "Yes, absolutely! **Hormonal acne, hirsutism (excess body/facial hair), and scalp hair thinning** are key clinical markers of PCOS & PCOD.\n\n"
                    "• **Why it occurs**: Elevated free androgen levels (testosterone) stimulate the sebaceous glands and hair follicles.\n"
                    "• **Management**: Spearmint tea (twice daily), low-GI anti-inflammatory nutrition, and Myo-Inositol support healthy androgen balance.\n\n"
                    "*(Note: Educational information only. Consult your Gynecologist or Dermatologist for personalized acne therapy.)*"
                ),
                "suggestions": [
                    "What foods reduce androgen levels?",
                    "What is a Low-GI diet?",
                    "Consult a verified Gynecologist"
                ]
            }
        elif 'cure' in msg_lower or 'reversible' in msg_lower or 'treat' in msg_lower:
            return {
                "text": (
                    "Regarding management & reversibility:\n\n"
                    "• **PCOD (Polycystic Ovarian Disease)** is highly reversible through structured dietary improvements, weight management, and physical exercise.\n"
                    "• **PCOS (Polycystic Ovary Syndrome)** is a metabolic & endocrine condition. While there is no single permanent 'cure', symptoms can be effectively managed into complete clinical remission through low-GI nutrition, stress reduction, and targeted medical guidance.\n\n"
                    "*(Consult our verified Endocrinologists & Gynecologists for clinical management.)*"
                ),
                "suggestions": [
                    "Difference between PCOD & PCOS?",
                    "Best exercises for PCOS",
                    "PCOS Risk Assessment"
                ]
            }

    # 4. DIFFERENCE BETWEEN PCOD & PCOS
    if any(w in msg_lower for w in ['difference', 'vs', 'versus', 'compare', 'different', 'between pcod', 'between pcos']):
        return {
            "text": (
                "Here is the key clinical **difference between PCOD and PCOS**:\n\n"
                "• **1. Condition Type**:\n"
                "   - **PCOD (Polycystic Ovarian Disease)**: A hormonal condition where ovaries release immature or partially mature eggs that turn into cysts.\n"
                "   - **PCOS (Polycystic Ovary Syndrome)**: A broader endocrine & metabolic disorder affecting hormones, insulin sensitivity, and ovulation.\n\n"
                "• **2. Severity & Reversibility**:\n"
                "   - **PCOD**: Milder, non-metabolic in early stages, and **highly reversible** through low-GI nutrition, weight control, and light exercise.\n"
                "   - **PCOS**: More severe, linked with high androgen levels, facial hair (hirsutism), metabolic insulin resistance, and potential risk of type 2 diabetes.\n\n"
                "• **3. Diagnostic Markers**:\n"
                "   - **PCOD**: Primarily ovarian cyst appearance on ultrasound scan with mild cycle delay.\n"
                "   - **PCOS**: Requires Rotterdam criteria (2 of 3: irregular cycles, hyperandrogenism, polycystic ovaries on ultrasound).\n\n"
                "*(Educational guidance. Take our PCOS/PCOD risk assessments on Femora for personalized evaluations!)*"
            ),
            "suggestions": [
                "What are common symptoms of PCOS?",
                "How to reverse PCOD with diet?",
                "Take PCOS Risk Assessment"
            ]
        }

    # 5. CAUSES OF PCOS / PCOD
    if any(w in msg_lower for w in ['cause', 'causes', 'why does', 'reason for pcos', 'why pcos', 'why pcod']):
        return {
            "text": (
                "Here are the primary underlying **causes and risk factors of PCOS & PCOD**:\n\n"
                "• **Insulin Resistance**: Up to 70% of women with PCOS produce excess insulin, which signals the ovaries to produce more androgen (male hormones).\n"
                "• **Low-Grade Inflammation**: Chronic low-grade inflammation stimulates polycystic ovaries to produce excess androgens.\n"
                "• **Hormonal Imbalance**: Elevated LH (Luteinizing Hormone) relative to FSH disrupts regular ovulation.\n"
                "• **Genetic Predisposition**: A family history of PCOS, irregular cycles, or type 2 diabetes increases likelihood.\n\n"
                "*(Educational guidance. Consult our specialist gynecologists for diagnostic evaluation.)*"
            ),
            "suggestions": [
                "What blood tests check for PCOS?",
                "What is a Low-GI diet?",
                "Take PCOS Risk Test"
            ]
        }

    # 6. DIAGNOSTIC TESTS
    if any(w in msg_lower for w in ['test', 'tests', 'diagnosis', 'ultrasound', 'blood test', 'lab', 'check']):
        return {
            "text": (
                "Key clinical **diagnostic tests for PCOS & PCOD** include:\n\n"
                "• **Pelvic Ultrasound Scan**: Assesses ovarian volume and counts fluid-filled follicles ('string of pearls' appearance).\n"
                "• **LH to FSH Ratio**: A high LH:FSH ratio (>2:1 or >3:1) indicates ovulatory disruption.\n"
                "• **Fasting Insulin & Glucose Tolerance Test**: Evaluates metabolic insulin resistance.\n"
                "• **Free & Total Serum Testosterone**: Measures circulating androgen levels.\n"
                "• **Lipid Profile & Thyroid (TSH)**: Rules out thyroid dysfunction or hyperprolactinemia.\n\n"
                "*(Consult our verified specialist doctors on Femora to order & review lab tests!)*"
            ),
            "suggestions": [
                "Book Gynecologist Consultation",
                "Take PCOS Risk Assessment",
                "What is PCOS?"
            ]
        }

    # 7. FERTILITY & PREGNANCY
    if any(w in msg_lower for w in ['pregnant', 'pregnancy', 'fertility', 'conceive', 'baby', 'getting pregnant']):
        return {
            "text": (
                "Regarding **PCOS/PCOD & Fertility**:\n\n"
                "• **Can you get pregnant with PCOS/PCOD?**: **Yes, absolutely!** PCOS is a leading cause of treatable anovulatory infertility, but it does not mean sterility.\n"
                "• **Key Focus**: Restoring regular ovulation through low-GI nutrition, Myo-Inositol, stress reduction, and ovulation-inducing medications (like Letrozole/Clomiphene under doctor supervision).\n"
                "• **PCOD vs PCOS**: PCOD rarely impacts fertility when managed early, whereas PCOS benefits from early metabolic tracking.\n\n"
                "*(Consult our verified Reproductive Endocrinologists & Gynecologists on Femora!)*"
            ),
            "suggestions": [
                "How to calculate ovulation date?",
                "Consult a Fertility Specialist",
                "Take PCOS Risk Assessment"
            ]
        }

    # 8. PCOS DEFINITION & OVERVIEW
    if ('pcos' in msg_lower and any(w in msg_lower for w in ['what is', 'definition', 'meaning', 'explain', 'overview'])) or msg_lower == 'what is pcos':
        return {
            "text": (
                "**PCOS (Polycystic Ovary Syndrome)** is a common endocrine and metabolic condition affecting reproductive-age females.\n\n"
                "• **Core Features**: It is characterized by androgen elevation (male hormones), ovulatory disruption (irregular or missed periods), and insulin resistance.\n"
                "• **Ovarian Appearance**: Ultrasounds often show multiple small, fluid-filled sacs (follicles) around the edges of the ovary.\n"
                "• **Metabolic Link**: Up to 70% of women with PCOS experience insulin resistance, which can influence weight and blood sugar regulation.\n\n"
                "*(Educational guidance. Use our PCOS ML Prediction tool for an early risk evaluation!)*"
            ),
            "suggestions": [
                "What are common symptoms of PCOS?",
                "Difference between PCOD and PCOS?",
                "Take PCOS Early Risk Test"
            ]
        }

    # 9. PCOD DEFINITION & OVERVIEW
    if ('pcod' in msg_lower and any(w in msg_lower for w in ['what is', 'definition', 'meaning', 'explain', 'overview'])) or msg_lower == 'what is pcod':
        return {
            "text": (
                "**PCOD (Polycystic Ovarian Disease)** is a hormonal condition where ovaries release immature or partially mature eggs, which turn into small cysts over time.\n\n"
                "• **Reversibility**: PCOD is considered milder than PCOS and is often **highly reversible** through targeted lifestyle, nutrition, and exercise modifications.\n"
                "• **Key Differences**: Unlike PCOS, PCOD does not usually involve severe metabolic complications or fertility disruption when managed early.\n\n"
                "*(Educational information only. Consult a specialist doctor on Femora for tailored care!)*"
            ),
            "suggestions": [
                "Difference between PCOD & PCOS?",
                "How to reverse PCOD with diet?",
                "Take PCOD Risk Assessment"
            ]
        }

    # 10. PCOS / PCOD SYMPTOMS
    if any(w in msg_lower for w in ['symptom', 'symptoms', 'signs', 'hirsutism', 'facial hair', 'acne', 'weight gain', 'hair loss']):
        return {
            "text": (
                "Here are the **primary clinical symptoms** associated with PCOS & PCOD:\n\n"
                "• **Irregular Menstrual Cycles**: Oligomenorrhea (cycles >35 days apart) or amenorrhea (missed periods for months).\n"
                "• **Excess Facial & Body Hair (Hirsutism)**: Coarse hair growth on chin, upper lip, chest, or abdomen due to elevated androgen levels.\n"
                "• **Hormonal Acne**: Persistent cystic breakouts along the jawline, chin, and lower face.\n"
                "• **Scalp Hair Thinning**: Male-pattern androgenic hair loss or crown thinning.\n"
                "• **Acanthosis Nigricans**: Skin darkening around neck folds, armpits, or groin area linked to insulin resistance.\n"
                "• **Weight Gain Resistance**: Difficulty losing weight despite healthy dietary efforts.\n\n"
                "*(Educational guidance. Please consult our specialist gynecologists for diagnostic evaluation.)*"
            ),
            "suggestions": [
                "Can acne be one of them?",
                "Can exercise help with PCOS?",
                "What blood tests check for PCOS?"
            ]
        }

    # 11. MENSTRUAL CYCLE & PERIOD TRACKING
    if any(w in msg_lower for w in ['track', 'tracking', 'period', 'cycle', 'ovulation', 'fertile', 'luteal', 'follicular', 'menstruation', 'late period']):
        return {
            "text": (
                "Here is how you can effectively **track and understand your menstrual cycle** on Femora:\n\n"
                "• **1. Log Key Dates**: Record the start date of your flow. A normal cycle averages 21 to 35 days.\n"
                "• **2. Track Symptoms & Flow**: Log flow intensity (light, medium, heavy), pain levels, mood, and symptoms daily.\n"
                "• **3. Identify Infradian Phases**:\n"
                "   - *Menstrual Phase (Days 1-5)*: Rest and low-impact movement.\n"
                "   - *Follicular Phase (Days 6-13)*: High energy, optimal time for strength training.\n"
                "   - *Ovulatory Phase (Days 14-16)*: Peak energy & fertility window.\n"
                "   - *Luteal Phase (Days 17-28)*: Progesterone dominates; focus on grounding foods & stress relief.\n\n"
                "Use Femora's **Period Tracker Tab** to calculate your exact ovulation date and fertile window!"
            ),
            "suggestions": [
                "How to calculate ovulation date?",
                "Why is my period irregular?",
                "What foods boost progesterone during Luteal Phase?"
            ]
        }

    # 12. EXERCISE & FITNESS
    if any(w in msg_lower for w in ['exercise', 'workout', 'gym', 'walking', 'yoga', 'fitness', 'weight loss', 'physical activity']):
        return {
            "text": (
                "Exercise is one of the most effective tools for managing PCOS & PCOD hormones:\n\n"
                "• **Low-Cortisol Resistance Training**: 25-30 minutes of progressive weight lifting or bodyweight exercises 3-4 times/week improves muscle insulin sensitivity.\n"
                "• **Steady-State Cardio**: Brisk walking, swimming, or cycling keeps stress hormones low while burning glucose.\n"
                "• **Avoid Excessive HIIT**: Overtraining with intense chronic cardio can spike cortisol, worsening hormonal breakouts and abdominal fat storage.\n"
                "• **Hormone-Balancing Yoga**: Diaphragmatic breathing and gentle yoga reduce nervous system tension.\n\n"
                "*(Educational guidance. Check out Femora's Workout Module for phase-specific routines!)*"
            ),
            "suggestions": [
                "Best workouts for Luteal phase",
                "How stress affects PCOS hormones",
                "PCOS diet and nutrition tips"
            ]
        }

    # 13. DIET & NUTRITION
    if any(w in msg_lower for w in ['diet', 'food', 'foods', 'nutrition', 'eat', 'eating', 'spearmint', 'flaxseed', 'sugar', 'low-gi', 'low gi']):
        return {
            "text": (
                "Hormonal nutrition is key for managing PCOS and PCOD insulin resistance:\n\n"
                "• **Low-Glycemic Index (Low-GI) Foods**: Choose quinoa, oats, lentils, sweet potatoes, and leafy greens to prevent blood glucose spikes.\n"
                "• **Anti-Inflammatory Fats**: Incorporate extra virgin olive oil, walnuts, chia seeds, and wild salmon.\n"
                "• **Spearmint Tea**: Drinking 2 cups of Spearmint tea daily has been clinically shown to support healthy androgen balance.\n"
                "• **Daily Dietary Fiber**: Aim for 30g daily fiber from flaxseed and legumes to support estrogen metabolism.\n"
                "• **Avoid**: Ultra-processed foods, refined white flour, and sugary drinks.\n\n"
                "*(Educational advice. Explore Femora's Diet Module for personalized meal guidance!)*"
            ),
            "suggestions": [
                "What is a Low-GI diet?",
                "Supplements for PCOS insulin resistance",
                "Consult a verified Nutritionist"
            ]
        }

    # 14. MENOPAUSE & PERIMENOPAUSE
    if any(w in msg_lower for w in ['menopause', 'perimenopause', 'hot flash', 'hot flashes', 'night sweat', 'night sweats', 'estrogen']):
        return {
            "text": (
                "Here is key educational guidance on **Perimenopause & Menopause Transition**:\n\n"
                "• **Vasomotor Symptoms**: Hot flashes and night sweats occur due to fluctuating estrogen levels affecting the brain's thermoregulatory center.\n"
                "• **Phytoestrogen Nutrition**: Incorporate natural flaxseed, soy isoflavones, and sesame seeds to support gentle estrogenic activity.\n"
                "• **Bone & Cardiac Health**: Prioritize Calcium (1200mg/day) and Vitamin D3 (2000 IU/day) combined with weight-bearing exercises to maintain bone density.\n"
                "• **Specialist Care**: Consult a Menopause Specialist to discuss Bioidentical Hormone Replacement Therapy (HRT) if symptoms significantly affect quality of life.\n\n"
                "*(Use Femora's Menopause Predictor module to evaluate your transition phase!)*"
            ),
            "suggestions": [
                "How to reduce hot flashes naturally?",
                "DXA Bone Density scan info",
                "Take Menopause Assessment"
            ]
        }

    # 15. UNRELATED / OUT-OF-SCOPE TOPICS
    if any(w in msg_lower for w in ['president', 'prime minister', 'weather', 'crypto', 'bitcoin', 'football', 'movie', 'python code', 'capital of']):
        return {
            "text": (
                "Hello! As your **Femora AI Companion & Dr. Teddy 🧸**, my primary expertise is dedicated to **Women's Health, PCOS, PCOD, Menopause, Cycle Syncing, and Hormonal Nutrition**.\n\n"
                "While I focus on health guidance, please feel free to ask me anything about:\n"
                "• Understanding PCOS & PCOD symptoms\n"
                "• Tracking your menstrual cycle and ovulation\n"
                "• Anti-inflammatory diet & exercise tips for hormonal balance\n"
                "• Booking appointments with verified specialist doctors\n\n"
                "How can I help you with your health today?"
            ),
            "suggestions": [
                "What is PCOS?",
                "What is PCOD?",
                "How do I track my cycle?",
                "Book Doctor Consultation"
            ]
        }

    # 16. SPECIFIC DYNAMIC RESPONSE FOR ANY OTHER QUESTION (No static template)
    clean_prompt = message.strip()
    return {
        "text": (
            f"Regarding your query **'{clean_prompt}'**:\n\n"
            f"Dr. Teddy 🧸 & Femora AI Companion provides structured guidance on your query:\n\n"
            f"1. **Clinical Context**: Questions regarding '{clean_prompt}' often involve hormonal regulation, menstrual cycle phase alignment, or insulin sensitivity.\n"
            f"2. **Recommended Action**: Track your daily symptoms on the Femora Period Tracker or take our PCOS/PCOD Risk Assessments for personalized AI model evaluation.\n"
            f"3. **Specialist Care**: Speak directly with verified specialist gynecologists on our Doctor Tab for tailored diagnostic testing.\n\n"
            f"*(Note: Educational guidance only. Please consult a qualified healthcare professional for medical diagnosis.)*"
        ),
        "suggestions": [
            "Difference between PCOD & PCOS?",
            "What are common PCOS symptoms?",
            "Book Doctor Consultation"
        ]
    }


@app.route('/api/ai/chat', methods=['POST'])
def ai_chat():
    data = request.get_json() or {}
    message = data.get('message', '').strip()
    user_id = data.get('userId') or data.get('user_id')
    history = data.get('history', [])

    if not message:
        return jsonify({"error": "Message is required"}), 400

    # Call Gemini GenAI SDK with message & context history
    gemini_response = call_gemini(message, history=history)

    if gemini_response:
        bot_text = gemini_response
        suggestions = [
            "What are common PCOS symptoms?",
            "How do I track my menstrual cycle?",
            "Consult a verified Gynecologist"
        ]
    else:
        # Dynamic, question-aware AI generator fallback
        dynamic_res = generate_dynamic_chat_response(message, history=history)
        bot_text = dynamic_res.get('text')
        suggestions = dynamic_res.get('suggestions', [])

    # Save to MongoDB / SQLite database if user_id is provided
    if user_id:
        try:
            db_save_chat({
                "id": "msg_usr_" + str(int(datetime.now().timestamp() * 1000)),
                "userId": user_id,
                "sender": "user",
                "text": message,
                "timestamp": datetime.now().isoformat()
            })
            db_save_chat({
                "id": "msg_bot_" + str(int(datetime.now().timestamp() * 1000)),
                "userId": user_id,
                "sender": "bot",
                "text": bot_text,
                "suggestions": suggestions,
                "timestamp": datetime.now().isoformat()
            })
        except Exception as e:
            print(f"[CHAT] Error saving chat message: {e}")

    return jsonify({
        "success": True,
        "text": bot_text,
        "suggestions": suggestions
    })


@app.route('/api/chat/save', methods=['POST'])
def save_chat():
    data = request.get_json() or {}
    db_save_chat(data)
    return jsonify({'success': True})


@app.route('/api/chat/history/<user_id>', methods=['GET'])
def get_chat_history(user_id):
    history = db_get_chat_history(user_id)
    return jsonify({'history': history})


# ---------------------------- CYCLE TRACKING LOGS ----------------------------

@app.route('/api/cycles/save', methods=['POST'])
def save_cycle():
    data = request.get_json() or {}
    cycle_doc = {
        "id": data.get('id', "cl_" + str(int(datetime.now().timestamp() * 1000))),
        "date": data.get('date', datetime.now().strftime("%Y-%m-%d")),
        "flow": data.get('flow', 'medium'),
        "mood": data.get('mood', 'calm'),
        "painLevel": data.get('painLevel', 3),
        "symptoms": data.get('symptoms', []),
        "notes": data.get('notes', ''),
        "userId": data.get('userId', 'usr_001'),
        "created_at": datetime.now().isoformat()
    }
    db_save_cycle(cycle_doc)
    return jsonify({'success': True, 'cycle': cycle_doc})


@app.route('/api/cycles/<user_id>', methods=['GET'])
def get_cycles(user_id):
    cycles = db_get_cycles(user_id)
    return jsonify({'cycles': cycles})


# ---------------------------- HEALTH ASSESSMENTS ----------------------------

@app.route('/api/assessments/save', methods=['POST'])
@app.route('/api/healthassessments/save', methods=['POST'])
def save_assessment():
    data = request.get_json() or {}
    assessment_doc = {
        "id": "asm_" + str(int(datetime.now().timestamp() * 1000)),
        "userId": data.get('userId', 'usr_001'),
        "data": data,
        "timestamp": datetime.now().isoformat()
    }
    db_save_assessment(assessment_doc)
    return jsonify({'success': True, 'assessment': assessment_doc})


@app.route('/api/assessments/<user_id>', methods=['GET'])
@app.route('/api/healthassessments/<user_id>', methods=['GET'])
def get_assessments(user_id):
    assessments = db_get_assessments(user_id)
    return jsonify({'assessments': assessments})


# ---------------------------- DOCTOR DIRECTORY & APPOINTMENTS ----------------------------

@app.route('/api/doctors', methods=['GET'])
def get_doctors():
    specialty = request.args.get('specialty')
    condition = request.args.get('condition')
    search = request.args.get('search')
    sort = request.args.get('sort')

    docs = []
    if db is not None:
        try:
            docs = list(db.doctors.find({}, {"_id": 0}))
        except Exception:
            pass

    if not docs:
        docs = VERIFIED_SHIVAMOGGA_DOCTORS

    # Specialty filter
    if specialty and specialty != 'All':
        sq = specialty.lower()
        docs = [d for d in docs if sq in (d.get('specialty') or '').lower() or sq in (d.get('subSpecialty') or '').lower()]

    # Condition filter
    if condition and condition != 'All':
        cq = condition.lower()
        docs = [d for d in docs if any(cq in c.lower() for c in d.get('conditions', []))]

    # Search query
    if search:
        sq = search.lower().strip()
        docs = [
            d for d in docs
            if sq in (d.get('name') or '').lower()
            or sq in (d.get('hospital') or '').lower()
            or sq in (d.get('qualification') or '').lower()
            or any(sq in exp.lower() for exp in d.get('expertise', []))
        ]

    # Sorting
    if sort == 'experience':
        docs.sort(key=lambda d: d.get('experienceYears') or 0, reverse=True)
    elif sort == 'name':
        docs.sort(key=lambda d: d.get('name', ''))

    return jsonify({
        "location": "Shivamogga, Karnataka",
        "count": len(docs),
        "doctors": docs
    })


@app.route('/api/doctors/<doc_id>', methods=['GET'])
def get_doctor_by_id(doc_id):
    doc = None
    if db is not None:
        try:
            doc = db.doctors.find_one({"id": doc_id}, {"_id": 0})
        except Exception:
            pass

    if not doc:
        doc = next((d for d in VERIFIED_SHIVAMOGGA_DOCTORS if d['id'] == doc_id), None)

    if not doc:
        return jsonify({'error': 'Doctor not found'}), 404

    return jsonify(doc)


@app.route('/api/appointments', methods=['GET'])
def get_all_appointments():
    user_id = request.args.get('userId')
    appts = db_get_appointments(user_id)
    return jsonify({'appointments': appts})


@app.route('/api/appointments/<user_id>', methods=['GET'])
def get_user_appointments(user_id):
    appts = db_get_appointments(user_id)
    return jsonify({'appointments': appts})


@app.route('/api/appointments', methods=['POST'])
def book_appointment():
    data = request.get_json() or {}
    patient_name = data.get('patientName')
    phone = data.get('phone')
    email = data.get('email')
    date = data.get('date')
    time_str = data.get('time')
    reason = data.get('reason')
    doc_id = data.get('doctorId')

    if not all([patient_name, phone, email, date, time_str, reason]):
        return jsonify({'error': 'Please fill all required fields (Name, Phone, Email, Date, Time, Reason)'}), 400

    doc = next((d for d in VERIFIED_SHIVAMOGGA_DOCTORS if d['id'] == doc_id), None)
    doc_name = data.get('doctorName') or (doc['name'] if doc else 'Specialist Doctor')
    doc_spec = data.get('doctorSpecialty') or (doc['specialty'] if doc else 'Gynecologist & Endocrinologist')
    hospital = data.get('hospital') or (doc['hospital'] if doc else 'Healthcare Facility')

    appt_id = "appt_" + str(int(datetime.now().timestamp() * 1000))
    new_appt = {
        "id": appt_id,
        "userId": data.get('userId', 'usr_001'),
        "doctorId": doc_id or 'doc_sujan',
        "doctorName": doc_name,
        "doctorSpecialty": doc_spec,
        "hospital": hospital,
        "hospitalAddress": data.get('hospitalAddress') or (doc.get('address') if doc else ''),
        "placeId": data.get('placeId'),
        "lat": data.get('lat'),
        "lng": data.get('lng'),
        "patientName": str(patient_name).strip(),
        "age": data.get('age', 28),
        "phone": str(phone).strip(),
        "email": str(email).strip(),
        "date": date,
        "time": time_str,
        "reason": str(reason).strip(),
        "status": "pending",
        "createdAt": datetime.now().isoformat(),
        "meetLink": None
    }

    db_save_appointment(new_appt)

    return jsonify({
        'message': 'Appointment requested successfully',
        'appointment': new_appt
    }), 201


@app.route('/api/appointments/<appt_id>/cancel', methods=['PATCH'])
@app.route('/api/appointments/<appt_id>', methods=['DELETE'])
def cancel_appointment(appt_id):
    db_cancel_appointment(appt_id)
    return jsonify({'message': 'Appointment cancelled successfully'})


# ---------------------------- MENTAL WELLNESS ANALYSIS ----------------------------

@app.route('/api/ai/mental-analysis', methods=['POST'])
def mental_analysis():
    data = request.get_json() or {}
    stress_score = int(data.get('stressScore', 5))
    entry_text = data.get('entryText', '')

    sentiment = 'Calm & Balanced'
    reflection = 'You are maintaining a steady emotional balance. Continue practicing mindfulness and gentle movement.'

    if stress_score >= 7 or any(w in entry_text.lower() for w in ['anxious', 'overwhelmed', 'stressed', 'exhausted', 'sad', 'crying', 'depressed']):
        sentiment = 'Elevated Stress & Burnout Risk'
        reflection = 'Your log indicates elevated nervous system tension. Remember that hormonal fluctuations during luteal and menstrual phases naturally affect neurotransmitters. Take 5 minutes for diaphragmatic box breathing now.'

    return jsonify({
        "sentiment": sentiment,
        "reflection": reflection,
        "recommendedExercises": [
            "4-7-8 Deep Box Breathing",
            "5-Minute PCOS Grounding Meditation",
            "Gentle Neck & Shoulder Release Yoga"
        ]
    })


# ---------------------------- ADMIN MANAGEMENT ----------------------------

@app.route('/api/auth/admin/users', methods=['GET'])
def get_all_users():
    users_list = db_get_all_users()
    return jsonify({'users': users_list})


@app.route('/api/auth/admin/users/<user_id>', methods=['DELETE'])
def delete_user(user_id):
    db_delete_user(user_id)
    return jsonify({'message': 'User account removed successfully'})


# ---------------------------- SPA FRONTEND SERVING ----------------------------

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_spa(path):
    if path.startswith('api/'):
        return jsonify({"error": "API route not found"}), 404

    target_file = os.path.join(app.static_folder, path)
    if path != "" and os.path.exists(target_file) and os.path.isfile(target_file):
        return send_from_directory(app.static_folder, path)
    else:
        index_path = os.path.join(app.static_folder, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(app.static_folder, 'index.html')
        else:
            return jsonify({
                "message": "Femora Backend API is running on port 5000. Build frontend static assets (npm run build in femora-frontend) to view UI on this port."
            })


# =============================================================================
# MAIN SERVER RUNNER
# =============================================================================

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    print("=" * 60)
    print(f"  FEMORA AI Platform - Full-Stack Single Host Server")
    print(f"  Running on http://localhost:{port}")
    print("=" * 60)
    app.run(host='0.0.0.0', port=port, debug=True)