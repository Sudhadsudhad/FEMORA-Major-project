"""
=============================================================================
FEMORA AI - Standalone Python CLI & Machine Learning Predictor
=============================================================================
Run this script directly with Python:
    python femora_cli.py
=============================================================================
"""

import sys
import os
import json
from datetime import datetime, timedelta

def run_pcos_ml_predictor():
    print("\n" + "="*60)
    print("  🌸 FEMORA AI - PCOS & Women's Health Clinical Assessor")
    print("="*60)
    
    # Interactive input prompts
    try:
        name = input("\nEnter Patient Name [Default: Elena]: ").strip() or "Elena"
        age = float(input("Enter Age (years) [28]: ").strip() or "28")
        weight = float(input("Enter Weight (kg) [62]: ").strip() or "62")
        height_cm = float(input("Enter Height (cm) [162]: ").strip() or "162")
        
        cycle_length = int(input("Average Cycle Length (days) [32]: ").strip() or "32")
        irregular_cycles = input("Are your cycles irregular or missed frequently? (y/n) [y]: ").strip().lower() in ['y', 'yes']
        hirsutism_score = int(input("Excess facial/body hair severity (0 to 10) [6]: ").strip() or "6")
        acne = input("Frequent cystic/hormonal acne flare-ups? (y/n) [y]: ").strip().lower() in ['y', 'yes']
        skin_darkening = input("Skin darkening on neck/body folds (Acanthosis)? (y/n) [y]: ").strip().lower() in ['y', 'yes']
    except KeyboardInterrupt:
        print("\nExiting assessment.")
        return

    # Calculations
    height_m = height_cm / 100.0
    bmi = weight / (height_m * height_m)
    
    score = 0
    max_score = 30
    factors = []
    
    if irregular_cycles or cycle_length > 35 or cycle_length < 21:
        score += 8
        factors.append("Oligomenorrhea / Cycle Irregularity")
    if hirsutism_score >= 5:
        score += 7
        factors.append("Hyperandrogenism (Hirsutism Score >= 5)")
    if acne:
        score += 4
        factors.append("Persistent Hormonal Acne")
    if skin_darkening:
        score += 5
        factors.append("Acanthosis Nigricans (Insulin Resistance Indicator)")
    if bmi >= 25.0:
        score += 6
        factors.append(f"Elevated BMI ({round(bmi, 1)} kg/m²)")

    risk_percentage = min(round((score / max_score) * 100), 98)
    
    if risk_percentage >= 65:
        risk_category = "HIGH RISK"
        color_code = "🔴"
    elif risk_percentage >= 35:
        risk_category = "MODERATE RISK"
        color_code = "🟡"
    else:
        risk_category = "LOW RISK"
        color_code = "🟢"

    print("\n" + "-"*60)
    print(f"  CLINICAL SUMMARY FOR {name.upper()}")
    print("-"*60)
    print(f"• Age: {int(age)} | BMI: {round(bmi, 1)} kg/m²")
    print(f"• Calculated Risk Score: {risk_percentage}% {color_code} [{risk_category}]")
    print("\n• Identified Clinical Risk Factors:")
    for f in factors:
        print(f"   - {f}")
        
    print("\n• Recommended Action Plan:")
    print("   1. Request Serum Total & Free Testosterone + Fasting Insulin blood panel.")
    print("   2. Schedule Pelvic Ultrasound for ovarian follicle count.")
    print("   3. Adopt anti-inflammatory, low-GI Mediterranean diet plan.")
    print("   4. Consult Dr. Teddy & Femora Specialist Gynecologists.")
    print("="*60 + "\n")

if __name__ == "__main__":
    run_pcos_ml_predictor()
